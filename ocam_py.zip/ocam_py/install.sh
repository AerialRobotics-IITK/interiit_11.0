#!/bin/bash

curl https://bootstrap.pypa.io/pip/2.7/get-pip.py --output get-pip.py
sudo python2 get-pip.py # or simply python
pip2 install v4l2